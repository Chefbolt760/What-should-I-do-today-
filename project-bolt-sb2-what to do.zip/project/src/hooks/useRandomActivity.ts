import { useState, useEffect } from 'react';
import { Activity, FilterOptions } from '../types';
import activities from '../data/activities';

export const useRandomActivity = (filterOptions: FilterOptions) => {
  const [selectedActivity, setSelectedActivity] = useState<Activity | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [favorites, setFavorites] = useState<Activity[]>([]);
  
  // Load favorites from localStorage on initial render
  useEffect(() => {
    const savedFavorites = localStorage.getItem('favoriteActivities');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  // Save favorites to localStorage when they change
  useEffect(() => {
    localStorage.setItem('favoriteActivities', JSON.stringify(favorites));
  }, [favorites]);

  const filterActivities = (activities: Activity[], options: FilterOptions) => {
    return activities.filter(activity => {
      const moodMatch = options.mood === 'any' || activity.moods.includes(options.mood) || activity.moods.includes('any');
      const timeMatch = options.timeOfDay === 'any' || activity.timeOfDay.includes(options.timeOfDay) || activity.timeOfDay.includes('any');
      const weatherMatch = options.weather === 'any' || activity.weather.includes(options.weather) || activity.weather.includes('any');
      
      return moodMatch && timeMatch && weatherMatch;
    });
  };

  const spinForActivity = () => {
    setIsSpinning(true);
    
    // Filter activities based on current options
    const filteredActivities = filterActivities(activities, filterOptions);
    
    // If no activities match the filters, return null after spinning
    if (filteredActivities.length === 0) {
      setTimeout(() => {
        setSelectedActivity(null);
        setIsSpinning(false);
      }, 2000);
      return;
    }
    
    // Pick a random index from the filtered activities
    const randomIndex = Math.floor(Math.random() * filteredActivities.length);
    
    // Simulate spinning for 2 seconds before revealing the activity
    setTimeout(() => {
      setSelectedActivity(filteredActivities[randomIndex]);
      setIsSpinning(false);
    }, 2000);
  };

  const toggleFavorite = (activity: Activity) => {
    const isFavorite = favorites.some(fav => fav.id === activity.id);
    
    if (isFavorite) {
      setFavorites(favorites.filter(fav => fav.id !== activity.id));
    } else {
      setFavorites([...favorites, activity]);
    }
  };

  const isFavorite = (activity: Activity | null) => {
    if (!activity) return false;
    return favorites.some(fav => fav.id === activity.id);
  };

  return {
    selectedActivity,
    isSpinning,
    spinForActivity,
    favorites,
    toggleFavorite,
    isFavorite,
  };
};