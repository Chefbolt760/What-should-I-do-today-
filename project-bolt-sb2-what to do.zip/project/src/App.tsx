import React, { useState, useEffect } from 'react';
import ActivitySpinner from './components/ActivitySpinner';
import FilterControls from './components/FilterControls';
import ActivityCard from './components/ActivityCard';
import FavoritesDrawer from './components/FavoritesDrawer';
import { useRandomActivity } from './hooks/useRandomActivity';
import { FilterOptions, Activity } from './types';
import { Heart, Github } from 'lucide-react';

function App() {
  const [filters, setFilters] = useState<FilterOptions>({
    mood: 'any',
    timeOfDay: 'any',
    weather: 'any'
  });
  
  const [showFavorites, setShowFavorites] = useState(false);
  const [noMatchingActivities, setNoMatchingActivities] = useState(false);
  
  const { 
    selectedActivity, 
    isSpinning, 
    spinForActivity, 
    favorites, 
    toggleFavorite, 
    isFavorite 
  } = useRandomActivity(filters);

  useEffect(() => {
    setNoMatchingActivities(false);
  }, [filters]);

  useEffect(() => {
    if (!isSpinning && !selectedActivity && filters) {
      setNoMatchingActivities(true);
    } else {
      setNoMatchingActivities(false);
    }
  }, [isSpinning, selectedActivity, filters]);

  const handleFilterChange = (newFilters: FilterOptions) => {
    setFilters(newFilters);
  };

  const selectFavoriteActivity = (activity: Activity) => {
    setShowFavorites(false);
  };

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-fuchsia-100 via-purple-100 to-indigo-100 overflow-hidden">
      {/* Animated background patterns */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(#8B5CF6_1px,transparent_1px)] [background-size:20px_20px] opacity-20 animate-float"></div>
        <div className="absolute inset-0 bg-[radial-gradient(#EC4899_1px,transparent_1px)] [background-size:30px_30px] opacity-10 animate-float-reverse"></div>
      </div>
      
      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600 animate-pulse">
          What Should I Do Today?
        </h1>
        <button 
          onClick={() => setShowFavorites(true)}
          className="flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 text-sm font-medium text-purple-700"
        >
          <Heart className="w-4 h-4" />
          <span className="hidden sm:inline">Favorites</span>
          {favorites.length > 0 && (
            <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-2 py-0.5 rounded-full text-xs font-bold">
              {favorites.length}
            </span>
          )}
        </button>
      </header>
      
      {/* Main content */}
      <main className="relative z-10 container mx-auto px-4 py-6 flex flex-col items-center justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 w-full max-w-5xl">
          <div className="flex flex-col items-center space-y-8">
            <ActivitySpinner 
              isSpinning={isSpinning}
              onSpin={spinForActivity}
              selectedActivity={selectedActivity}
            />
            
            {noMatchingActivities && (
              <div className="bg-red-50 text-red-600 px-6 py-4 rounded-xl text-sm max-w-md shadow-lg animate-bounce">
                <p className="font-medium">Oops! No matching activities found! 🤔</p>
                <p>Try changing some options or select "Any" for more results.</p>
              </div>
            )}
          </div>
          
          <div className="flex flex-col items-center space-y-8">
            <FilterControls 
              filters={filters}
              onFilterChange={handleFilterChange}
            />
            
            {selectedActivity && !isSpinning && (
              <ActivityCard 
                activity={selectedActivity}
                isFavorite={isFavorite(selectedActivity)}
                onToggleFavorite={() => toggleFavorite(selectedActivity)}
              />
            )}
          </div>
        </div>
      </main>
      
      <FavoritesDrawer 
        favorites={favorites}
        isOpen={showFavorites}
        onClose={() => setShowFavorites(false)}
        onSelectActivity={selectFavoriteActivity}
        onRemoveFavorite={toggleFavorite}
      />
      
      {showFavorites && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-40"
          onClick={() => setShowFavorites(false)}
        ></div>
      )}
      
      {/* Footer */}
      <footer className="relative z-10 p-6 text-center">
        <p className="flex items-center justify-center gap-2 text-sm font-medium text-purple-600">
          <span>Made with</span>
          <Heart className="w-4 h-4 text-pink-500 animate-bounce" fill="currentColor" />
          <span>• &copy; {new Date().getFullYear()}</span>
        </p>
      </footer>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
        
        @keyframes float-reverse {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(10px); }
        }
        
        .animate-float {
          animation: float 20s ease-in-out infinite;
        }
        
        .animate-float-reverse {
          animation: float-reverse 25s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}

export default App;