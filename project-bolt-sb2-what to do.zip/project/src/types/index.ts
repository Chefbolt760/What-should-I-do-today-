export type Mood = 'happy' | 'bored' | 'energetic' | 'relaxed' | 'any';

export type TimeOfDay = 'morning' | 'afternoon' | 'evening' | 'night' | 'any';

export type Weather = 'sunny' | 'rainy' | 'cloudy' | 'snowy' | 'any';

export type ActivityCategory = 'indoor' | 'outdoor' | 'creative' | 'social' | 'productive' | 'relaxing';

export interface Activity {
  id: string;
  title: string;
  description: string;
  moods: Mood[];
  timeOfDay: TimeOfDay[];
  weather: Weather[];
  category: ActivityCategory;
  duration: string;
  imageUrl?: string;
}

export interface FilterOptions {
  mood: Mood;
  timeOfDay: TimeOfDay;
  weather: Weather;
}