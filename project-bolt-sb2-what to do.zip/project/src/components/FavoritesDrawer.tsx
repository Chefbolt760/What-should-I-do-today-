import React from 'react';
import { Activity } from '../types';
import { X } from 'lucide-react';

interface FavoritesDrawerProps {
  favorites: Activity[];
  isOpen: boolean;
  onClose: () => void;
  onSelectActivity: (activity: Activity) => void;
  onRemoveFavorite: (activity: Activity) => void;
}

const FavoritesDrawer: React.FC<FavoritesDrawerProps> = ({ 
  favorites, 
  isOpen, 
  onClose, 
  onSelectActivity,
  onRemoveFavorite
}) => {
  return (
    <div 
      className={`fixed inset-y-0 right-0 w-full md:w-80 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50 ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}
    >
      <div className="flex justify-between items-center p-4 border-b">
        <h2 className="text-xl font-semibold text-gray-800">Favorite Activities</h2>
        <button 
          onClick={onClose}
          className="text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>
      </div>
      
      <div className="p-4 overflow-y-auto h-[calc(100vh-64px)]">
        {favorites.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p>You haven't added any favorites yet.</p>
            <p className="mt-2 text-sm">Activities you love will appear here.</p>
          </div>
        ) : (
          <ul className="space-y-3">
            {favorites.map(activity => (
              <li 
                key={activity.id}
                className="bg-gray-50 rounded-lg p-3 hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <div className="flex justify-between">
                  <div 
                    className="flex-1" 
                    onClick={() => onSelectActivity(activity)}
                  >
                    <h3 className="font-medium text-gray-800">{activity.title}</h3>
                    <p className="text-sm text-gray-500 line-clamp-2 mt-1">{activity.description}</p>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onRemoveFavorite(activity);
                    }}
                    className="self-start text-gray-400 hover:text-red-500 p-1"
                    aria-label="Remove from favorites"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default FavoritesDrawer;