import React from 'react';
import { Activity } from '../types';
import { Clock, Tag, Heart } from 'lucide-react';

interface ActivityCardProps {
  activity: Activity;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}

const ActivityCard: React.FC<ActivityCardProps> = ({ 
  activity, 
  isFavorite, 
  onToggleFavorite 
}) => {
  // Activity category images from Pexels
  const categoryImages: Record<string, string> = {
    indoor: 'https://images.pexels.com/photos/3932929/pexels-photo-3932929.jpeg',
    outdoor: 'https://images.pexels.com/photos/2387873/pexels-photo-2387873.jpeg',
    creative: 'https://images.pexels.com/photos/3747139/pexels-photo-3747139.jpeg',
    social: 'https://images.pexels.com/photos/5082976/pexels-photo-5082976.jpeg',
    productive: 'https://images.pexels.com/photos/1485548/pexels-photo-1485548.jpeg',
    relaxing: 'https://images.pexels.com/photos/3757952/pexels-photo-3757952.jpeg',
  };

  const categoryColors: Record<string, string> = {
    indoor: 'bg-blue-100 text-blue-800 border-blue-200',
    outdoor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    creative: 'bg-violet-100 text-violet-800 border-violet-200',
    social: 'bg-rose-100 text-rose-800 border-rose-200',
    productive: 'bg-amber-100 text-amber-800 border-amber-200',
    relaxing: 'bg-teal-100 text-teal-800 border-teal-200',
  };
  
  const categoryColor = categoryColors[activity.category] || 'bg-gray-100 text-gray-800 border-gray-200';
  const categoryImage = categoryImages[activity.category];

  return (
    <div className="bg-white bg-opacity-95 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden w-full max-w-md transform transition-all duration-300 hover:shadow-2xl animate-card-appear">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={categoryImage} 
          alt={activity.category}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        <button 
          onClick={onToggleFavorite}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/90 hover:bg-white transition-colors shadow-lg"
          aria-label={isFavorite ? "Remove from favorites" : "Add to favorites"}
        >
          <Heart 
            className={`w-6 h-6 ${isFavorite ? 'fill-rose-500 text-rose-500' : 'text-gray-600'}`}
          />
        </button>
      </div>
      
      <div className="p-6">
        <div className="mb-4">
          <h2 className="text-2xl font-bold text-gray-800 mb-2">{activity.title}</h2>
          <p className="text-gray-600">{activity.description}</p>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          <span className={`px-3 py-1 rounded-full border ${categoryColor} font-medium text-sm`}>
            {activity.category}
          </span>
          <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-700 border border-gray-200 font-medium text-sm flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {activity.duration}
          </span>
        </div>
        
        <button 
          onClick={onToggleFavorite}
          className={`w-full py-3 rounded-xl font-medium transition-all duration-300 ${
            isFavorite 
              ? 'bg-rose-50 text-rose-600 hover:bg-rose-100' 
              : 'bg-violet-50 text-violet-600 hover:bg-violet-100'
          }`}
        >
          {isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
        </button>
      </div>
    </div>
  );
};

export default ActivityCard;