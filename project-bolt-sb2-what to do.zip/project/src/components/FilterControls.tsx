import React from 'react';
import { Mood, TimeOfDay, Weather, FilterOptions } from '../types';
import { 
  Sun, 
  Cloud, 
  CloudRain, 
  CloudSnow, 
  Coffee, 
  Sunset, 
  Moon, 
  Smile, 
  Frown, 
  Zap, 
  Heart
} from 'lucide-react';

interface FilterControlsProps {
  filters: FilterOptions;
  onFilterChange: (filters: FilterOptions) => void;
}

const FilterControls: React.FC<FilterControlsProps> = ({ filters, onFilterChange }) => {
  const handleMoodChange = (mood: Mood) => {
    onFilterChange({ ...filters, mood });
  };

  const handleTimeChange = (timeOfDay: TimeOfDay) => {
    onFilterChange({ ...filters, timeOfDay });
  };

  const handleWeatherChange = (weather: Weather) => {
    onFilterChange({ ...filters, weather });
  };

  return (
    <div className="bg-white bg-opacity-80 backdrop-blur-md rounded-xl p-6 shadow-lg w-full max-w-md">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Customize Your Activity</h2>

      <div className="mb-5">
        <h3 className="text-sm font-medium text-gray-600 mb-2">I'm feeling:</h3>
        <div className="grid grid-cols-5 gap-2">
          <button
            onClick={() => handleMoodChange('happy')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.mood === 'happy' 
                ? 'bg-yellow-100 text-yellow-700 ring-2 ring-yellow-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-yellow-50'
            }`}
          >
            <Smile className="w-5 h-5 mb-1" />
            Happy
          </button>
          <button
            onClick={() => handleMoodChange('bored')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.mood === 'bored' 
                ? 'bg-gray-200 text-gray-700 ring-2 ring-gray-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Frown className="w-5 h-5 mb-1" />
            Bored
          </button>
          <button
            onClick={() => handleMoodChange('energetic')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.mood === 'energetic' 
                ? 'bg-orange-100 text-orange-700 ring-2 ring-orange-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-orange-50'
            }`}
          >
            <Zap className="w-5 h-5 mb-1" />
            Energetic
          </button>
          <button
            onClick={() => handleMoodChange('relaxed')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.mood === 'relaxed' 
                ? 'bg-blue-100 text-blue-700 ring-2 ring-blue-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-blue-50'
            }`}
          >
            <Heart className="w-5 h-5 mb-1" />
            Relaxed
          </button>
          <button
            onClick={() => handleMoodChange('any')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.mood === 'any' 
                ? 'bg-purple-100 text-purple-700 ring-2 ring-purple-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-purple-50'
            }`}
          >
            <span className="text-lg mb-1">🎲</span>
            Any
          </button>
        </div>
      </div>

      <div className="mb-5">
        <h3 className="text-sm font-medium text-gray-600 mb-2">Time of day:</h3>
        <div className="grid grid-cols-5 gap-2">
          <button
            onClick={() => handleTimeChange('morning')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.timeOfDay === 'morning' 
                ? 'bg-yellow-100 text-yellow-700 ring-2 ring-yellow-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-yellow-50'
            }`}
          >
            <Coffee className="w-5 h-5 mb-1" />
            Morning
          </button>
          <button
            onClick={() => handleTimeChange('afternoon')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.timeOfDay === 'afternoon' 
                ? 'bg-blue-100 text-blue-700 ring-2 ring-blue-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-blue-50'
            }`}
          >
            <Sun className="w-5 h-5 mb-1" />
            Afternoon
          </button>
          <button
            onClick={() => handleTimeChange('evening')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.timeOfDay === 'evening' 
                ? 'bg-orange-100 text-orange-700 ring-2 ring-orange-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-orange-50'
            }`}
          >
            <Sunset className="w-5 h-5 mb-1" />
            Evening
          </button>
          <button
            onClick={() => handleTimeChange('night')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.timeOfDay === 'night' 
                ? 'bg-indigo-100 text-indigo-700 ring-2 ring-indigo-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-indigo-50'
            }`}
          >
            <Moon className="w-5 h-5 mb-1" />
            Night
          </button>
          <button
            onClick={() => handleTimeChange('any')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.timeOfDay === 'any' 
                ? 'bg-purple-100 text-purple-700 ring-2 ring-purple-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-purple-50'
            }`}
          >
            <span className="text-lg mb-1">🎲</span>
            Any
          </button>
        </div>
      </div>

      <div className="mb-5">
        <h3 className="text-sm font-medium text-gray-600 mb-2">Weather:</h3>
        <div className="grid grid-cols-5 gap-2">
          <button
            onClick={() => handleWeatherChange('sunny')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.weather === 'sunny' 
                ? 'bg-yellow-100 text-yellow-700 ring-2 ring-yellow-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-yellow-50'
            }`}
          >
            <Sun className="w-5 h-5 mb-1" />
            Sunny
          </button>
          <button
            onClick={() => handleWeatherChange('cloudy')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.weather === 'cloudy' 
                ? 'bg-gray-200 text-gray-700 ring-2 ring-gray-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Cloud className="w-5 h-5 mb-1" />
            Cloudy
          </button>
          <button
            onClick={() => handleWeatherChange('rainy')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.weather === 'rainy' 
                ? 'bg-blue-100 text-blue-700 ring-2 ring-blue-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-blue-50'
            }`}
          >
            <CloudRain className="w-5 h-5 mb-1" />
            Rainy
          </button>
          <button
            onClick={() => handleWeatherChange('snowy')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.weather === 'snowy' 
                ? 'bg-indigo-100 text-indigo-700 ring-2 ring-indigo-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-indigo-50'
            }`}
          >
            <CloudSnow className="w-5 h-5 mb-1" />
            Snowy
          </button>
          <button
            onClick={() => handleWeatherChange('any')}
            className={`p-2 rounded-lg flex flex-col items-center justify-center text-xs transition-all ${
              filters.weather === 'any' 
                ? 'bg-purple-100 text-purple-700 ring-2 ring-purple-400' 
                : 'bg-gray-50 text-gray-600 hover:bg-purple-50'
            }`}
          >
            <span className="text-lg mb-1">🎲</span>
            Any
          </button>
        </div>
      </div>
    </div>
  );
};

export default FilterControls;