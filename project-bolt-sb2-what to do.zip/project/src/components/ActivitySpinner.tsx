import React, { useState, useEffect } from 'react';
import { Activity } from '../types';

interface ActivitySpinnerProps {
  isSpinning: boolean;
  onSpin: () => void;
  selectedActivity: Activity | null;
}

const ActivitySpinner: React.FC<ActivitySpinnerProps> = ({ 
  isSpinning, 
  onSpin, 
  selectedActivity 
}) => {
  const [rotation, setRotation] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    if (isSpinning) {
      const interval = setInterval(() => {
        setRotation(prev => prev + 15);
      }, 50);

      return () => {
        clearInterval(interval);
        if (selectedActivity) {
          setShowConfetti(true);
          setTimeout(() => setShowConfetti(false), 3000);
        }
      };
    }
  }, [isSpinning, selectedActivity]);

  return (
    <div className="relative flex flex-col items-center justify-center">
      {showConfetti && (
        <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
          <div className="confetti-container">
            {Array.from({ length: 50 }).map((_, index) => (
              <div
                key={index}
                className="confetti"
                style={{
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 3}s`,
                  backgroundColor: `hsl(${Math.random() * 360}, 80%, 60%)`,
                }}
              />
            ))}
          </div>
        </div>
      )}

      <div 
        className={`spinner-wheel w-72 h-72 rounded-full border-8 border-white/20 flex items-center justify-center relative shadow-2xl mb-8 transition-transform duration-1000 ${isSpinning ? 'spinning' : ''}`}
        style={{ 
          transform: `rotate(${rotation}deg)`,
          background: 'conic-gradient(from 0deg, #F472B6, #C084FC, #818CF8, #34D399, #F472B6)'
        }}
      >
        <div className="absolute inset-0 rounded-full bg-white/10 backdrop-blur-sm"></div>
        <div className="z-10 w-48 h-48 rounded-full bg-white/95 backdrop-blur-md flex items-center justify-center shadow-inner">
          {selectedActivity ? (
            <div className="text-center p-4 animate-fade-in">
              <p className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-violet-600 to-pink-600">
                {selectedActivity.title}
              </p>
            </div>
          ) : (
            <p className="text-gray-500 text-center font-medium px-4">
              Spin to discover your next adventure!
            </p>
          )}
        </div>
      </div>

      <button
        onClick={onSpin}
        disabled={isSpinning}
        className={`
          px-8 py-4 rounded-full font-bold text-white shadow-xl
          transform transition-all duration-300
          ${isSpinning 
            ? 'bg-gray-400 cursor-not-allowed scale-95' 
            : 'bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-700 hover:to-pink-700 hover:scale-105 hover:shadow-2xl'
          }
        `}
      >
        {isSpinning ? 'Finding something fun...' : 'Spin the Wheel!'}
      </button>

      <style jsx>{`
        .spinning {
          transition: transform 0.5s cubic-bezier(0.25, 0.1, 0.25, 1);
        }
        
        .confetti {
          position: absolute;
          width: 10px;
          height: 10px;
          opacity: 0;
          animation: confetti-fall 3s ease-in-out forwards;
        }
        
        @keyframes confetti-fall {
          0% {
            opacity: 1;
            transform: translateY(-50px) rotate(0deg);
          }
          100% {
            opacity: 0;
            transform: translateY(500px) rotate(360deg);
          }
        }
        
        .animate-fade-in {
          animation: fadeIn 0.5s ease-in;
        }
        
        @keyframes fadeIn {
          0% { opacity: 0; }
          100% { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default ActivitySpinner;