import { Activity } from '../types';

const activities: Activity[] = [
  {
    id: '1',
    title: 'Morning meditation',
    description: 'Start your day with 10 minutes of mindfulness meditation to set a positive tone for the day.',
    moods: ['relaxed', 'any'],
    timeOfDay: ['morning', 'any'],
    weather: ['any'],
    category: 'relaxing',
    duration: '10-15 min'
  },
  {
    id: '2',
    title: 'Go for a bike ride',
    description: 'Enjoy some fresh air and exercise with a refreshing bike ride around your neighborhood or a local park.',
    moods: ['energetic', 'happy', 'any'],
    timeOfDay: ['morning', 'afternoon', 'any'],
    weather: ['sunny', 'cloudy', 'any'],
    category: 'outdoor',
    duration: '30-60 min'
  },
  {
    id: '3',
    title: 'Learn a new recipe',
    description: 'Challenge yourself in the kitchen by trying a new recipe you\'ve never made before.',
    moods: ['bored', 'happy', 'any'],
    timeOfDay: ['afternoon', 'evening', 'any'],
    weather: ['rainy', 'snowy', 'any'],
    category: 'creative',
    duration: '1-2 hours'
  },
  {
    id: '4',
    title: 'Movie marathon',
    description: 'Pick a film series or director and have a cozy movie marathon with snacks and comfortable blankets.',
    moods: ['relaxed', 'bored', 'any'],
    timeOfDay: ['afternoon', 'evening', 'night', 'any'],
    weather: ['rainy', 'snowy', 'any'],
    category: 'indoor',
    duration: '3+ hours'
  },
  {
    id: '5',
    title: 'Call an old friend',
    description: 'Reconnect with someone you haven\'t spoken to in a while and catch up on life.',
    moods: ['happy', 'relaxed', 'bored', 'any'],
    timeOfDay: ['afternoon', 'evening', 'any'],
    weather: ['any'],
    category: 'social',
    duration: '30-60 min'
  },
  {
    id: '6',
    title: 'Declutter a space',
    description: 'Choose one small area of your home to organize and declutter for a sense of accomplishment.',
    moods: ['energetic', 'bored', 'any'],
    timeOfDay: ['morning', 'afternoon', 'any'],
    weather: ['rainy', 'cloudy', 'any'],
    category: 'productive',
    duration: '30-60 min'
  },
  {
    id: '7',
    title: 'Try a new coffee shop',
    description: 'Explore a local coffee shop you\'ve never visited before and try their specialty drink.',
    moods: ['happy', 'relaxed', 'any'],
    timeOfDay: ['morning', 'afternoon', 'any'],
    weather: ['sunny', 'cloudy', 'any'],
    category: 'social',
    duration: '1 hour'
  },
  {
    id: '8',
    title: 'Take a photography walk',
    description: 'Grab your camera or phone and take a walk focused on capturing interesting photos.',
    moods: ['creative', 'happy', 'relaxed', 'any'],
    timeOfDay: ['morning', 'afternoon', 'evening', 'any'],
    weather: ['sunny', 'cloudy', 'any'],
    category: 'creative',
    duration: '1-2 hours'
  },
  {
    id: '9',
    title: 'Start a journal',
    description: 'Begin a journal with your thoughts, goals, or gratitude list to reflect on your life.',
    moods: ['relaxed', 'any'],
    timeOfDay: ['morning', 'evening', 'night', 'any'],
    weather: ['any'],
    category: 'creative',
    duration: '15-30 min'
  },
  {
    id: '10',
    title: 'Take a bubble bath',
    description: 'Indulge in a relaxing bubble bath with candles, music, and perhaps a good book.',
    moods: ['relaxed', 'any'],
    timeOfDay: ['evening', 'night', 'any'],
    weather: ['any'],
    category: 'relaxing',
    duration: '30-60 min'
  },
  {
    id: '11',
    title: 'Learn a TikTok dance',
    description: 'Pick a trending dance and learn the choreography for fun and light exercise.',
    moods: ['energetic', 'happy', 'bored', 'any'],
    timeOfDay: ['any'],
    weather: ['any'],
    category: 'indoor',
    duration: '30 min'
  },
  {
    id: '12',
    title: 'Start a garden project',
    description: 'Plant some seeds, repot a plant, or create a small herb garden for your kitchen.',
    moods: ['happy', 'relaxed', 'any'],
    timeOfDay: ['morning', 'afternoon', 'any'],
    weather: ['sunny', 'cloudy', 'any'],
    category: 'outdoor',
    duration: '1-2 hours'
  },
  {
    id: '13',
    title: 'Visit a local museum',
    description: 'Explore the exhibitions at a nearby museum or gallery you haven\'t been to in a while.',
    moods: ['curious', 'happy', 'any'],
    timeOfDay: ['morning', 'afternoon', 'any'],
    weather: ['rainy', 'cloudy', 'any'],
    category: 'indoor',
    duration: '2-3 hours'
  },
  {
    id: '14',
    title: 'Plan a future trip',
    description: 'Research and create an itinerary for a dream vacation, even if it\'s for the distant future.',
    moods: ['happy', 'bored', 'any'],
    timeOfDay: ['any'],
    weather: ['any'],
    category: 'productive',
    duration: '1-2 hours'
  },
  {
    id: '15',
    title: 'Stargazing',
    description: 'Find a dark spot, lay out a blanket, and observe the night sky – identify constellations if you can.',
    moods: ['relaxed', 'any'],
    timeOfDay: ['night', 'any'],
    weather: ['clear', 'any'],
    category: 'outdoor',
    duration: '1 hour'
  },
  {
    id: '16',
    title: 'Random act of kindness',
    description: 'Do something unexpectedly nice for someone else, whether a stranger or someone you know.',
    moods: ['happy', 'energetic', 'any'],
    timeOfDay: ['any'],
    weather: ['any'],
    category: 'social',
    duration: 'varies'
  },
  {
    id: '17',
    title: 'Create a vision board',
    description: 'Collect images and words that represent your goals and dreams, and arrange them on a board.',
    moods: ['creative', 'happy', 'any'],
    timeOfDay: ['any'],
    weather: ['any'],
    category: 'creative',
    duration: '1-3 hours'
  },
  {
    id: '18',
    title: 'Try a new workout routine',
    description: 'Look up a new type of exercise online and follow along – maybe yoga, HIIT, or dance fitness.',
    moods: ['energetic', 'any'],
    timeOfDay: ['morning', 'afternoon', 'any'],
    weather: ['any'],
    category: 'indoor',
    duration: '30-60 min'
  },
  {
    id: '19',
    title: 'Write a letter to your future self',
    description: 'Compose a letter to the person you\'ll be in 5 years, including hopes, goals, and advice.',
    moods: ['reflective', 'relaxed', 'any'],
    timeOfDay: ['evening', 'night', 'any'],
    weather: ['any'],
    category: 'creative',
    duration: '30 min'
  },
  {
    id: '20',
    title: 'Have a picnic',
    description: 'Pack some food and drinks and enjoy them outdoors at a park or scenic spot.',
    moods: ['happy', 'relaxed', 'any'],
    timeOfDay: ['morning', 'afternoon', 'any'],
    weather: ['sunny', 'any'],
    category: 'outdoor',
    duration: '1-2 hours'
  }
];

export default activities;